<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;


class Provider extends Controller
{
    /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return \Illuminate\Http\Response
     */
    public function redirectToProvider()
    {
        return Socialite::driver('azure')->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleProviderCallback()
    {
        $user = Socialite::driver('azure')->user();

 // Set login credentials
        $userModel = User::where('email', $user->email)->first();
      if ($userModel == null) {
                    Session::flash('error', 'Invalid username or password.');
                    return redirect()->route('users.getLogin');
      }

      Auth::login($userModel, false);
  
        //Login was succesful.
        Session::put('myrealuser', Auth::id());

        return redirect()->intended('/');
    }
}



  