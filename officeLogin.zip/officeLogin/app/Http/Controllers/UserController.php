<?php

namespace App\Http\Controllers;
use App\Models\User;
use Laravel\Socialite\Facades\Socialite;
use Session;
use Hash;
use Str;
use Auth;

class UserController extends Controller
{

    public function redirectToProvider()
    {
        return Socialite::driver('azure')->redirect();
    }

    public function handleProviderCallback()
    {
        $user = Socialite::driver('azure')->user();

    // Set login credentials
    //dd($user);
    $userModel = User::where('email', $user->email)->first();
    if ($userModel == null) {
        $userModel = User::create(["email" => $user->email, "password" => Hash::make(Str::random(40)), "name" => $user->name]);
        

        /*
        Session::flash('error', 'Invalid username or password.');
        return redirect()->route('users.getLogin');
        */
      }

    Auth::login($userModel, false);

    
    //Login was succesful.
    Session::put('myrealuser', Auth::id());

    return redirect()->intended('/');
    }
}

